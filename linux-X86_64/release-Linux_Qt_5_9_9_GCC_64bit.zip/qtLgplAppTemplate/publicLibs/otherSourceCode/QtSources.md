
open source  (put your own server, or a google drive url
https://download.qt.io/archive/qt/5.12/5.12.5/single/qt-everywhere-src-5.12.5.zip
