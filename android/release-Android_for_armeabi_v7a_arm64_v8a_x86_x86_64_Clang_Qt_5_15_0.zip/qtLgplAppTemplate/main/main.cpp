#include "main.h"
int main(int argc, char *argv[])
{
  return _main(argc,argv);
}

