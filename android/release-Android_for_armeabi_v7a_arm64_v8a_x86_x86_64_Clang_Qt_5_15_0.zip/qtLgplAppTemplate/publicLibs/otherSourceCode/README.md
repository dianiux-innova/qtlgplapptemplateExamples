Al files in this folder will be added to release.zip
You can put all QT Sources, or a URL in your server to download


